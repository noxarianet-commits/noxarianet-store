---
name: Aura
colors:
  surface: '#15121b'
  surface-dim: '#15121b'
  surface-bright: '#3c3742'
  surface-container-lowest: '#100d16'
  surface-container-low: '#1d1a24'
  surface-container: '#221e28'
  surface-container-high: '#2c2833'
  surface-container-highest: '#37333e'
  on-surface: '#e8dfee'
  on-surface-variant: '#ccc3d8'
  inverse-surface: '#e8dfee'
  inverse-on-surface: '#332f39'
  outline: '#958da1'
  outline-variant: '#4a4455'
  surface-tint: '#d2bbff'
  primary: '#d2bbff'
  on-primary: '#3f008e'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#732ee4'
  secondary: '#cebdff'
  on-secondary: '#381385'
  secondary-container: '#4f319c'
  on-secondary-container: '#bea8ff'
  tertiary: '#ffb784'
  on-tertiary: '#4f2500'
  tertiary-container: '#a15100'
  on-tertiary-container: '#ffe0cd'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb784'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#15121b'
  on-background: '#e8dfee'
  surface-variant: '#37333e'
typography:
  h1:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h3:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin: 32px
---

## Brand & Style

This design system is engineered for a premium, future-forward e-commerce experience. The brand personality is sophisticated, immersive, and high-tech, targeting a tech-savvy audience that values aesthetic precision and high-end digital craftsmanship. 

The visual style is a meticulous blend of **Glassmorphism** and **Futurism**. It utilizes deep spatial depth created through semi-transparent layers, high-refraction blurs, and luminous accents. The goal is to evoke a sense of "digital luxury"—where interfaces feel like physical glass floating in a cosmic void, illuminated by soft, neon energy sources.

## Colors

The palette is rooted in a "Deep Space" navy base, providing a high-contrast canvas for the purple spectrum. 

- **Primary (#7C3AED):** Used for structural importance and primary brand moments.
- **Secondary (#A78BFA):** Used for supporting elements and interactive states.
- **Accent (#C084FC):** Reserved for high-energy "glow" moments, such as active states, notifications, or call-to-action highlights.
- **Surface & Border:** To achieve the glass effect, surfaces use low-opacity white fills with thin, semi-transparent borders to catch the light.

## Typography

This design system utilizes **Inter** across all levels to maintain a systematic, utilitarian, and clean futuristic look. 

Headlines use a "Heavy" or "Extra Bold" weight with tight letter spacing to create a high-impact, editorial feel. Body text remains neutral with generous line height for maximum legibility against the dark background. Labels use an uppercase styling with increased letter spacing to provide a technical, "HUD" (Heads-Up Display) aesthetic.

## Layout & Spacing

The design system employs a **12-column fluid grid** with generous margins to emphasize minimalism and airiness. 

The spacing rhythm is built on an 8px base unit. Wide gutters (24px) ensure that glass components have enough negative space to prevent the "blur" effects from feeling cluttered. Content containers should use large internal padding (md or lg) to maintain the premium, spacious feel of the brand.

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and light-based elevation rather than traditional shadows.

1.  **Backdrop Blur:** All cards and overlays must apply a `backdrop-filter: blur(20px)`.
2.  **Tonal Stacking:** Surfaces closer to the user are lighter and more opaque.
3.  **Glows:** High-priority elements use an outer glow (box-shadow) utilizing the Accent color with a 20-40px blur radius at low opacity (15-30%).
4.  **Edge Treatment:** Every glass container features a 1px "inner" border that acts as a rim-light, simulating light hitting the edge of a glass pane.

## Shapes

The shape language is defined by extremely smooth, oversized "2xl" corners. This softens the futuristic aesthetic, making it feel organic and approachable rather than cold or sharp.

- **Primary Cards:** Use the `rounded-xl` (1.5rem / 24px) setting for substantial presence.
- **Buttons & Inputs:** Follow the same logic, ensuring consistency across all interactive touchpoints.
- **Background Elements:** Use large, soft radial gradients (blobs) to break the grid and add organic depth behind the glass layers.

## Components

### Buttons
- **Primary:** Solid Deep Purple (#7C3AED) with a subtle glowing box-shadow of the Accent color. Text is white and bold.
- **Ghost/Glass:** Transparent background with the 1px rim-light border and backdrop blur.

### Cards (Glass Cards)
- Components use `rgba(255, 255, 255, 0.03)` as a base fill. 
- Must include `2xl` rounded corners (1.5rem).
- A 1px border using a linear gradient (top-left to bottom-right) from `rgba(255,255,255,0.2)` to `transparent`.

### Input Fields
- Dark, recessed backgrounds with a soft border.
- On focus, the border transitions to the Accent Color (#C084FC) with a subtle neon outer glow.

### Chips & Badges
- Small, pill-shaped elements with high-contrast text. Use the Accent color for "New" or "Sale" items to draw immediate attention.

### Product Grid
- High-quality imagery is paramount. Product photos should be isolated or have minimal backgrounds to sit cleanly behind the glass-card containers.